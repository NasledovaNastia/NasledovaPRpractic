﻿using practic.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practic
{
    /// <summary>
    /// Логика взаимодействия для AddClient.xaml
    /// </summary>
    public partial class AddClient : Window
    {
        Entities.Entities database = new Entities.Entities();
        Entities.Clients clients = new Entities.Clients();
        public AddClient()
        {
            InitializeComponent();
            DataContext = clients;
            CBTypeUser.ItemsSource = database.RolesUsers.ToList();
        }

        private void BTAdd_Click(object sender, RoutedEventArgs e)
        {
            database.Clients.Add(clients);
            database.SaveChanges();
            this.Close();
        }

        private void BTBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
