﻿using practic.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practic
{
    /// <summary>
    /// Логика взаимодействия для AddOrders.xaml
    /// </summary>
    public partial class AddOrders : Window
    {
        Entities.Entities database = new Entities.Entities();
        Entities.OrderService orderService = new Entities.OrderService();
        Entities.Orders orders = new Entities.Orders();
        public AddOrders()
        {
            InitializeComponent();
            DataContext = orderService;
            DataContext= orders;
            //объявляем источник данных для боксов
            CBTypeProduct.ItemsSource = database.Clients.ToList();
            CBSupplier.ItemsSource = database.RentalServices.ToList();
            CBStatus.ItemsSource=database.OrderStatuses.ToList();
        }

        private void BTAdd_Click(object sender, RoutedEventArgs e)
        {
            if (CBTypeProduct.SelectedIndex > -1 && CBStatus.SelectedIndex>-1)
            {
                //добавление данных сначало в одну таблицу
                Entities.Clients users = CBTypeProduct.SelectedItem as Entities.Clients;
                Orders ord = new Orders();
                ord.id_order = int.Parse(TBId.Text);
                ord.idClient = users.id_client;
                ord.idOrderStatus=CBStatus.SelectedIndex+1;
                ord.CreateDate= DateTime.Now;
                ord.TimeCreate=DateTime.Now.TimeOfDay.ToString();
                ord.RentalTime= int.Parse(TBCountHours.Text);
                database.Orders.Add(ord);
                database.SaveChanges();
                this.Close();
            }
            if (CBSupplier.SelectedIndex > -1)
            {
                //добавление данных в другую с использование только что добавлненной записи
                Entities.RentalServices rentalServices = CBSupplier.SelectedItem as Entities.RentalServices;
                OrderService ord = new OrderService();
                ord.idService = rentalServices.id_rentalService;
                ord.idOrder = int.Parse(TBId.Text);
                database.OrderService.Add(ord);
                database.SaveChanges();
                this.Close();
            }
           
        }

        private void BTBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
