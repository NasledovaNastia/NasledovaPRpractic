﻿using practic.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practic
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        Entities.Entities database;
        private Users[] users;
        private Entities.Entities context;
        public Admin()
        {
            InitializeComponent();
            database = new Entities.Entities();
            CBFilterType.ItemsSource = database.Users.ToList();
            context = new Entities.Entities();
            LoadData();
        }
        public void LoadData()
        {
            users = context.Users.ToArray();
            users = FilterTypeUser(users);
            DGUser.ItemsSource = users.ToList();
        }
        private Users[] FilterTypeUser(Users[] users)
        {
            if (CBFilterType.SelectedIndex > -1)
                users = users.Where(p => p.Login == CBFilterType.SelectedValue.ToString()).ToArray();
            return users;
        }

        private void CBFilterType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }
    }
}
