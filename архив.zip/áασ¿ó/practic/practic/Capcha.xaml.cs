﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practic
{
    /// <summary>
    /// Логика взаимодействия для Capcha.xaml
    /// </summary>
    public partial class Capcha : Window
    {
        string CaptchaText = "";
        String pwd;
        int MistackeCaptcha = 0;
        public Capcha()
        {
            InitializeComponent();
            Generation();
        }
        int not = 15;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        private void timerTick(object sender, EventArgs e)
        {
            if (not == 0)
            {
                this.IsEnabled = true;
                MessageBox.Show("Можете вводить captcha!!!");
                timer.Stop();
                MistackeCaptcha = 0;
                not = 15;
            }
            else
            {
                not--;
            }

        }
        private void BTOk_Click(object sender, RoutedEventArgs e)
        {
            
            if (TBCapcha.Text != String.Empty)
            {
                if (TBTextCapcha.Text == TBCapcha.Text)
                {
                    this.Close();
                }
                else
                {
                    MistackeCaptcha++;
                    Generation();
                    if (MistackeCaptcha > 2)
                    {
                        this.IsEnabled = false;
                        TBCapcha.Clear();
                        MessageBox.Show("Слишком много попыток, подождите", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                        timer.Tick += new EventHandler(timerTick);
                        timer.Interval = new TimeSpan(0, 0, 1);
                        timer.Start();
                    }
                    else
                        MessageBox.Show("Каптча не пройдена!", "Ошибка проверки", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
            }
            else
                MessageBox.Show("Заполните поле каптчи!", "Ошибка проверки", MessageBoxButton.OK, MessageBoxImage.Stop);

        }

        private void BTUpdate_Click(object sender, RoutedEventArgs e)
        {
            Generation();
        }
        public void Generation()
        {
            //генерация текста каптчи и его смещения
            CNVVisualShum.Children.Clear();
            CaptchaText = " ";
            CaptchaText += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            CaptchaText += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,y,z";
            CaptchaText += "1,2,3,4,5,6,7,8,9,0";
            char[] a = { ',' };
            String[] ar = CaptchaText.Split(a);
            pwd = "";
            string temp = " ";
            Random capR = new Random();
            for (int i = 0; i < 4; i++)
            {
                temp = ar[(capR.Next(0, ar.Length))];
                 pwd += temp;

            }
            RotateTransform rotateTransform = new RotateTransform();
            TextBlock textCap = new TextBlock();
            rotateTransform.Angle = capR.Next(-20, 20);
            textCap.Text = pwd;
            TBTextCapcha.Text = pwd;
            TBTextCapcha.Visibility=Visibility.Hidden; 
            textCap.FontSize = 32;
            textCap.RenderTransform = rotateTransform;
            Canvas.SetLeft(textCap, capR.Next(20, 100));
            Canvas.SetTop(textCap, capR.Next(20, 30));
            CNVVisualShum.Children.Add(textCap);

            //генерация визуального шума
            for (int i = 0; i < 600; i++)
            {
                Ellipse ellipse = new Ellipse();
                int r = capR.Next(3, 5);
                ellipse.Height = r;
                ellipse.Width = r;
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)capR.Next(1, 255), (byte)capR.Next(1, 255), (byte)capR.Next(1, 233)));
                ellipse.Fill = brus;
                Canvas.SetLeft(ellipse, capR.Next(250));
                Canvas.SetTop(ellipse, capR.Next(100));
                CNVVisualShum.Children.Add(ellipse);
            }
            for (int i = 0; i < 2; i++)
            {
                Line line = new Line();
                line.X1 = capR.Next(0, 50);
                line.Y1 = capR.Next(0, 50);
                line.X2 = capR.Next(150, 250);
                line.Y2 = capR.Next(51, 100);
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)capR.Next(1, 255), (byte)capR.Next(1, 255), (byte)capR.Next(1, 233)));
                line.Stroke = brus;
                line.StrokeThickness = 3;
                CNVVisualShum.Children.Add(line);
            }

            
        }
    }
}
