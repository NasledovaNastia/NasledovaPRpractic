﻿using practic.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practic
{
    /// <summary>
    /// Логика взаимодействия для Client.xaml
    /// </summary>
    public partial class Client : Window
    {
        Entities.Entities database;
        private Clients[] clients;
        private Entities.Entities context;
        public Client()
        {
            InitializeComponent();
            database = new Entities.Entities();
            context = new Entities.Entities();
            LoadData();
        }
        public void LoadData()
        {
            clients = context.Clients.ToArray();
            clients=FindClient(clients);
            DGUser.ItemsSource = clients.ToList();
        }
        private Clients[] FindClient(Clients[] clients)
        {
            if (TBSearch.Text != String.Empty)
            {
                clients = clients.Where(p => p.LastName.ToLower()
                    .Contains(TBSearch.Text.ToLower())).ToArray();
                if (clients.Length == 0)
                    clients = clients.Where(p => p.Name.ToLower()
                    .Contains(TBSearch.Text.ToLower())).ToArray();
            }
            return clients;
        }

        private void CBFilterType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }

        private void AddServises_Click(object sender, RoutedEventArgs e)
        {
            AddClient addOrders = new AddClient();
            addOrders.ShowDialog();
            LoadData();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SellerAndOldSeller client = new SellerAndOldSeller();
            client.Show();
        }

        private void TBSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }
    }
}