﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace practic
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {   Entities.Entities bd= new Entities.Entities();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void DontLook_Click(object sender, RoutedEventArgs e)
        {
            TBPassword.Text = PBPassword.Password;
            PBPassword.Visibility = Visibility.Collapsed;
            TBPassword.Visibility = Visibility.Visible;
            Look.Visibility = Visibility.Visible;
            DontLook.Visibility = Visibility.Collapsed;
        }

        private void Look_Click(object sender, RoutedEventArgs e)
        {
            PBPassword.Password = TBPassword.Text;
            TBPassword.Visibility = Visibility.Collapsed;
            PBPassword.Visibility = Visibility.Visible;
            DontLook.Visibility = Visibility.Visible;
            Look.Visibility = Visibility.Collapsed;
        }
        int kolvo_error = 0;

        private void Inputt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TBPassword.Text = PBPassword.Password;
                PBPassword.Password=TBPassword.Text;
                if (TBLogin.Text == String.Empty | PBPassword.Password == String.Empty | TBPassword.Text == String.Empty)
                {
                    MessageBox.Show("Заполните все поля!", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                { //поиск логина и пароля в бд
                    var user = bd.Users.FirstOrDefault(x => x.Login == TBLogin.Text && 
                    (x.PassWord == PBPassword.Password || x.PassWord == TBPassword.Text));
                    if (user != null)
                    {   
                        //разграничение прав доступа
                        switch (user.idRole)
                        {
                            case 1:
                                Admin admin= new Admin();
                                admin.Show();
                                this.Close();
                                break;
                            case 2:
                                SellerAndOldSeller sellerAndOldSeller= new SellerAndOldSeller();
                                sellerAndOldSeller.Show();
                                this.Close();
                                break;
                            case 3:
                                SellerAndOldSeller sellerAndOldSeller2 = new SellerAndOldSeller();
                                sellerAndOldSeller2.Show();
                                this.Close();
                                break;
                        }
                    }
                    else
                    {

                        kolvo_error++;
                        CheckUser();
                    }
                }

            }
            catch
            {

            }


        }
        int not = 10;
        System.Windows.Threading.DispatcherTimer timer2 = new System.Windows.Threading.DispatcherTimer();
        public void CheckUser()
        {
            if (kolvo_error == 1)
            {
                MessageBox.Show("Неверный логин или пароль", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (kolvo_error == 2)
            {
                Capcha capcha = new Capcha();
                capcha.ShowDialog();
            }
            if (kolvo_error >= 3)
            {
                timer2.Tick += new EventHandler(timerTick2);
                timer2.Interval = new TimeSpan(0, 0, 1);
                timer2.Start();
                if (not != 0)
                {
                    this.IsEnabled = false;
                    MessageBox.Show(String.Format("Вход заблокирован на 10 секунд", not));
                }
            }
        }
        private void timerTick2(object sender, EventArgs e)
        {
            if (not == 0)
            {
                this.IsEnabled = true; ;
                MessageBox.Show("Можете входить в систему");
                timer2.Stop();
                not = 10;
            }
            else
            {
                not--;
            }

        }
    }
}
