﻿using practic.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace practic
{
    /// <summary>
    /// Логика взаимодействия для SellerAndOldSeller.xaml
    /// </summary>
    public partial class SellerAndOldSeller : Window
    {
        Entities.Entities database;
        private OrderService[] rentalServices;
        private Entities.Entities context;
        public SellerAndOldSeller()
        {
            InitializeComponent();
            database = new Entities.Entities();
            context = new Entities.Entities();
            LoadData();
        }
        public void LoadData()
        {
            rentalServices = context.OrderService.ToArray();
            DGUser.ItemsSource = rentalServices.ToList();
        }
       

        private void CBFilterType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }

        private void AddServises_Click(object sender, RoutedEventArgs e)
        {
            AddOrders addOrders = new AddOrders();
            addOrders.ShowDialog();
            LoadData();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Client client= new Client();
            client.Show();
        }
    }
}
