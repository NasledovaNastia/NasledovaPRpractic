create table RolesUsers
(id_role int primary key ,
NameRole nvarchar(150) not null)

create table LoginStatuses
(id__loginStatus int primary key,
NameLoginStatus nvarchar(150) not null)

create table OrderStatuses
(id_orderStatus int primary key ,
NameOrderStatus nvarchar(150) not null)

create table RentalServices
(id_rentalService int primary key,
NameService nvarchar(150) not null,
CodeService nvarchar(150) not null,
Price decimal not null)

create table Users
(id_user int primary key ,
LastName nvarchar(150) not null,
[Name] nvarchar(150) not null,
Patronymic nvarchar(150) not null,
[Login] nvarchar(150) not null,
[PassWord] nvarchar(150) not null,
idRole int references RolesUsers(id_role),
LastLogin DateTime not null,
LastLoginStatus int references LoginStatuses(id__loginStatus))

create table Clients
(id_client int primary key not null,
LastName nvarchar(150) not null,
[Name] nvarchar(150) not null,
Patronymic nvarchar(150) not null,
PassportSeries int not null,
PassportNumber int not null,
BirthDate Date not null,
IndexAdress int not null,
City nvarchar(150) not null,
Street nvarchar(150) not null,
HomeNumber int not null,
FlatNumber int not null,
Email nvarchar(150) not null,
[Password] nvarchar(150) not null)

create table Orders
(id_order int primary key not null,
CodeOrder nvarchar(150) not null,
CreateDate Date not null,
TimeCreate nvarchar(150) not null,
idClient int references Clients(id_client),
idOrderStatus int references OrderStatuses(id_orderStatus),
CloseDate Date ,
RentalTime int)

create table OrderService
(idOrder int references Orders(id_order) not null,
idService int references RentalServices(id_rentalService))